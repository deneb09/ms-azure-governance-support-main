# ms-azure-governance-support

##This repository holds the technical assets used to monitor Azure Platform services as defined in Managed Services Azure Governance and Support service description.